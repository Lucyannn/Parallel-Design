#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>

void gaussEliminationMPI(float** A, int N, int rank, int size) {
    // ÿ�����̷��������
    int rows_per_process = N / size;
    int remainder = N % size;

    int start_row = rank * rows_per_process + std::min(rank, remainder);
    int end_row = start_row + rows_per_process - 1;
    if (rank < remainder) ++end_row;

    // ��ȥ����
    for (int k = 0; k < N; ++k) {
        int owner = k / rows_per_process;
        if (k % rows_per_process < remainder) {
            owner = k / (rows_per_process + 1);
        }
        else {
            owner = (k - remainder) / rows_per_process;
        }
        // �����k�еĽ��̽��г�������
        if (rank == owner) {
            float pivot = A[k][k];
            for (int j = k + 1; j < N; ++j) {
                A[k][j] /= pivot;
            }
            A[k][k] = 1.0;
        }
        // �㲥��k�е�����
        MPI_Bcast(A[k], N, MPI_FLOAT, owner, MPI_COMM_WORLD);

        // ������ȥ����
        if (rank > owner) {
            for (int i = std::max(start_row, k + 1); i <= end_row; ++i) {
                float factor = A[i][k];
                for (int j = k + 1; j < N; ++j) {
                    A[i][j] -= A[k][j] * factor;
                }
                A[i][k] = 0.0;
            }
        }
    }
}
int main(int argc, char* argv[]) {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("mpi02.csv");
    std::cout << "111" << std::endl;
    // ��ʼ��MPI����
    MPI_Init(&argc, &argv);
    std::cout << "222" << std::endl;
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start, end;
    std::cout << "333" << std::endl;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; ++i) {
            A[i] = new float[N];
        }
    std::cout << "444" << std::endl;
        if (rank == 0) {
            std::stringstream ss;
            ss << sizeIndex + 1;
            std::ifstream infile("matrix" + ss.str() + ".txt");
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    infile >> A[i][j];
                }
            }
            infile.close();
        }

        start = MPI_Wtime();
        // �㲥�����С�����н���
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
        std::cout << "555" << std::endl;
        // �㲥�������ݸ����н���
        for (int i = 0; i < N; ++i) {
            MPI_Bcast(A[i], N, MPI_FLOAT, 0, MPI_COMM_WORLD);
        }
        std::cout << "666" << std::endl;
        
        gaussEliminationMPI(A, N, rank, size);
        end = MPI_Wtime();

        std::cout << "777" << std::endl;
        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }

        for (int i = 0; i < N; ++i) {
            delete[] A[i];
        }
        delete[] A;
    }

    // ����MPI
    MPI_Finalize();
    outfile.close();
    return 0;
}
