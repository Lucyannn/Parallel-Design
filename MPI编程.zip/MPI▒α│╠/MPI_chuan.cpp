﻿#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>

void gaussElimination(float** A, int N) {
    for (int k = 0; k < N; ++k) {
        float pivot = A[k][k];
        for (int j = k + 1; j < N; ++j) {
            A[k][j] /= pivot;
        }
        A[k][k] = 1.0;

        for (int i = k + 1; i < N; ++i) {
            float factor = A[i][k];
            for (int j = k + 1; j < N; ++j) {
                A[i][j] -= A[k][j] * factor;
            }
            A[i][k] = 0.0;
        }
    }
}
int main() {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("chuan——01.csv");
    std::cout << "0000" << std::endl;
    // 初始化MPI环境
    MPI_Init(NULL, NULL);
    double start, end;
    std::cout << "1111" << std::endl;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; i++) {
            A[i] = new float[N];
        }
        std::cout << "2222" << std::endl;
        std::stringstream ss;
        ss << sizeIndex + 1;
        std::ifstream infile("matrix" + ss.str() + ".txt");
        //std::ifstream infile("matrix" + std::to_string(sizeIndex + 1) + ".txt");
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                infile >> A[i][j];
            }
        }
        infile.close();
        std::cout << "3333" << std::endl;

        start = MPI_Wtime();
        gaussElimination(A, N);
        end = MPI_Wtime();

        double elapsed = end - start;
        std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
        outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;

        for (int i = 0; i < N; i++) {
            delete[] A[i];
        }
        delete[] A;
    }

    // 结束MPI环境
    MPI_Finalize();
    outfile.close();
    return 0;
}

