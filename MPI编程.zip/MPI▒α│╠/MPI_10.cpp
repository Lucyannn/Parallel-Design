#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>

void gaussEliminationPipelineMPI(float** A, int N, int rank, int size) {
    // ÿ�����̷��������
    int rows_per_process = N / size;
    int remainder = N % size;

    int start_row = rank * rows_per_process + std::min(rank, remainder);
    int end_row = start_row + rows_per_process - 1;
    if (rank < remainder) ++end_row;

    // ��ȥ����
    for (int k = 0; k < N; ++k) {
        int owner = k / rows_per_process;
        if (k % rows_per_process < remainder) {
            owner = k / (rows_per_process + 1);
        }
        else {
            owner = (k - remainder) / rows_per_process;
        }

        // �����k�еĽ��̽��г�������
        if (rank == owner) {
            float pivot = A[k][k];
            for (int j = k + 1; j < N; ++j) {
                A[k][j] /= pivot;
            }
            A[k][k] = 1.0;
        }

        // ��Ե�ת����k�е�����
        if (rank == owner) {
            if (rank < size - 1) {
                MPI_Send(A[k], N, MPI_FLOAT, rank + 1, 0, MPI_COMM_WORLD);
            }
        }
        else {
            MPI_Recv(A[k], N, MPI_FLOAT, rank - 1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (rank < size - 1) {
                MPI_Send(A[k], N, MPI_FLOAT, rank + 1, 0, MPI_COMM_WORLD);
            }
        }
        // ������ȥ����
        for (int i = std::max(start_row, k + 1); i <= end_row; ++i) {
            if (i > k) {
                float factor = A[i][k];
                for (int j = k + 1; j < N; ++j) {
                    A[i][j] -= A[k][j] * factor;
                }
                A[i][k] = 0.0;
            }
        }
    }
}


int main(int argc, char* argv[]) {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("mpi_pipeline.csv");
    std::cout << "111" << std::endl;
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start, end;
    std::cout << "111" << std::endl;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; ++i) {
            A[i] = new float[N];
        }
        std::cout << "111" << std::endl;
        if (rank == 0) {
            std::stringstream ss;
            ss << sizeIndex + 1;
            std::ifstream infile("matrix" + ss.str() + ".txt");
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    infile >> A[i][j];
                }
            }
            infile.close();
        }

        start = MPI_Wtime();
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

        for (int i = 0; i < N; ++i) {
            MPI_Bcast(A[i], N, MPI_FLOAT, 0, MPI_COMM_WORLD);
        }
        std::cout << "111" << std::endl;
        gaussEliminationPipelineMPI(A, N, rank, size);
        end = MPI_Wtime();

        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }
        std::cout << "111" << std::endl;
        for (int i = 0; i < N; ++i) {
            delete[] A[i];
        }
        delete[] A;
    }

    MPI_Finalize();
    outfile.close();
    return 0;
}
