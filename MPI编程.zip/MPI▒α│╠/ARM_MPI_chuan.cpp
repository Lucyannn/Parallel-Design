#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>

void gaussElimination(float** A, int N) {
    for (int k = 0; k < N; ++k) {
        float pivot = A[k][k];
        for (int j = k + 1; j < N; ++j) {
            A[k][j] /= pivot;
        }
        A[k][k] = 1.0;

        for (int i = k + 1; i < N; ++i) {
            float factor = A[i][k];
            for (int j = k + 1; j < N; ++j) {
                A[i][j] -= A[k][j] * factor;
            }
            A[i][k] = 0.0;
        }
    }
}
int main() {
    std::vector<int> sizes;
    sizes.push_back(100);
    sizes.push_back(250);
    sizes.push_back(500);
    sizes.push_back(750);
    sizes.push_back(1000);
    sizes.push_back(2000);
    sizes.push_back(3000);
    sizes.push_back(4000);

    std::ofstream outfile("chuan——01.csv");
    // 初始化MPI环境
    MPI_Init(NULL, NULL);
    double start, end;
    for (int sizeIndex = 0; sizeIndex < 8; ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; i++) {
            A[i] = new float[N];
        }
        std::stringstream ss;
        ss << sizeIndex + 1;
        std::string filename = "matrix" + ss.str() + ".txt";
        std::ifstream infile(filename.c_str());
        
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                infile >> A[i][j];
            }
        }
        infile.close();

        start = MPI_Wtime();
        gaussElimination(A, N);
        end = MPI_Wtime();

        double elapsed = end - start;
        std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
        outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;

        for (int i = 0; i < N; i++) {
            delete[] A[i];
        }
        delete[] A;
    }

    // 结束MPI环境
    MPI_Finalize();
    outfile.close();
    return 0;
}
