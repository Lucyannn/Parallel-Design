#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>

void gaussElimination(float** A, int N, int rank, int size) {
    for (int k = 0; k < N; ++k) {
        // ����Խ���Ԫ�صĽ��̽��й㲥
        float pivot;
        if (k % size == rank) {
            pivot = A[k][k];
        }
        MPI_Bcast(&pivot, 1, MPI_FLOAT, k % size, MPI_COMM_WORLD);
        // ���н��̶��Լ�������н��г�������
        for (int i = k + 1; i < N; ++i) {
            if (k % size == rank) {
                A[i][k] /= pivot;
            }
        }
        MPI_Bcast(&A[k][k], N - k, MPI_FLOAT, k % size, MPI_COMM_WORLD);
        // ��ȥ�׶Σ�ֱ���ڱ��ؽ��м���
        for (int j = k + 1; j < N; ++j) {
            if (j % size == rank) {
                for (int i = k + 1; i < N; ++i) {
                    A[i][j] -= A[i][k] * A[k][j];
                }
            }
        }
    }
}

int main(int argc, char* argv[]) {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("parallel_gauss_column.csv");

    MPI_Init(&argc, &argv);
    std::cout << "111" << std::endl;
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start, end;
    std::cout << "111" << std::endl;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; i++) {
            A[i] = new float[N];
        }
        std::cout << "111" << std::endl;
        std::stringstream ss;
        ss << sizeIndex + 1;
        std::ifstream infile("matrix" + ss.str() + ".txt");
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                infile >> A[i][j];
            }
        }
        infile.close();
        std::cout << "111" << std::endl;

        start = MPI_Wtime();
        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        gaussElimination(A, N, rank, size);
        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        end = MPI_Wtime();

        std::cout << "111" << std::endl;
        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }

        for (int i = 0; i < N; i++) {
            delete[] A[i];
        }
        delete[] A;
    }

    MPI_Finalize();
    outfile.close();
    return 0;
}
