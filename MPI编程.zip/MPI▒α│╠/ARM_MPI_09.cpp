#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>
#include<omp.h>
#include <arm_neon.h>

typedef struct {
    int k;      // 消去的轮次
    int t_id;   // 线程 id
    float** A;  // 矩阵
    int n;      // 矩阵大小
} threadParam_t;

//串行
void threadFunc(threadParam_t* param) {
    int k = param->k;           // 消去的轮次
    int t_id = param->t_id;     // 线程编号
    float** A = param->A;       // 矩阵
    int n = param->n;           // 矩阵大小
    int i = k + t_id + 1;   // 获取自己的计算任务
    if (i < n) { // 检查是否越界
        for (int j = k + 1; j < n; ++j) {
            A[i][j] -= A[i][k] * A[k][j];
        }
        A[i][k] = 0;
    }
}
//NEON
void threadFunc(threadParam_t* param) {
    int k = param->k;           // 消去的轮次
    int t_id = param->t_id;     // 线程编号
    float** A = param->A;       // 矩阵
    int n = param->n;           // 矩阵大小

    int i = k + t_id + 1;   // 获取自己的计算任务

    float32x4_t vaik = vdupq_n_f32(A[i][k]);
    int j;
    for ( j = k + 1; j + 4 <= n; j += 4) {
        float32x4_t vakj = vld1q_f32(&A[k][j]);
        float32x4_t vaij = vld1q_f32(&A[i][j]);
        float32x4_t vx = vmulq_f32(vakj, vaik);
        vaij = vsubq_f32(vaij, vx);
        vst1q_f32(&A[i][j], vaij);
    }
    for (j; j < n;j++) {
        A[i][j] -= A[k][j] * A[i][k];
    }
    A[i][k] = 0.0f;
}
//高斯消去线程分配
void gaussEliminationMPI(float** A, int N, int rank, int size) {
    for (int k = 0; k < N; ++k) {
        // 找到主元，并广播给所有进程
        if (k % size == rank) {
            float pivot = A[k][k];
            for (int j = k + 1; j < N; ++j) {
                A[k][j] /= pivot;
            }
            A[k][k] = 1.0;
        }
        MPI_Bcast(&A[k][0], N, MPI_FLOAT, k % size, MPI_COMM_WORLD);

        // 每个进程消去它负责的行
        if (rank == k % size) {
            // 主线程进行除法操作
            int worker_count = N - 1 - k; // 工作线程数量
            threadParam_t* param = new threadParam_t[worker_count];
#pragma omp parallel for
            for (int t_id = 0; t_id < worker_count; t_id++) {
                param[t_id].k = k;
                param[t_id].t_id = t_id;
                param[t_id].A = A;
                param[t_id].n = N;
            }

            // 开启并行区域
#pragma omp parallel for
            for (int t_id = 0; t_id < worker_count; t_id++) {
                threadFunc(&param[t_id]);
            }
        }
    }
}


int main(int argc, char* argv[]) {
    std::ofstream outfile("mpi02.csv");

    std::vector<int> sizes;
    sizes.push_back(100);
    sizes.push_back(250);
    sizes.push_back(500);
    sizes.push_back(750);
    sizes.push_back(1000);
    sizes.push_back(2000);
    sizes.push_back(3000);
    sizes.push_back(4000);
    
    // 初始化MPI环境
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start, end;
for (int sizeIndex = 0; sizeIndex < 8; ++sizeIndex) {
    int N = sizes[sizeIndex];
    float** A = new float* [N];
    for (int i = 0; i < N; ++i) {
        A[i] = new float[N];
    }
    //读取数据
        if (rank == 0) {
            std::stringstream ss;
            ss << sizeIndex + 1;
            std::string filename = "matrix" + ss.str() + ".txt";
            std::ifstream infile(filename.c_str());
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    infile >> A[i][j];
                }
            }
            infile.close();
        }

        start = MPI_Wtime();
        // 广播矩阵大小给所有进程
        MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

        // 广播矩阵数据给所有进程
        for (int i = 0; i < N; ++i) {
            MPI_Bcast(A[i], N, MPI_FLOAT, 0, MPI_COMM_WORLD);
        }
        gaussEliminationMPI(A, N, rank, size);
        end = MPI_Wtime();

        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }

        for (int i = 0; i < N; ++i) {
            delete[] A[i];
        }
        delete[] A;
    }

    // 清理MPI
    MPI_Finalize();
    outfile.close();
    return 0;
}
