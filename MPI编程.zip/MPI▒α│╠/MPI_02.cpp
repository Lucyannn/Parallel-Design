#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <mpi.h>
#include <omp.h>

typedef struct {
    int k;      // ��ȥ���ִ�
    int t_id;   // �߳� id
    float** A;  // ����
    int n;      // �����С
} threadParam_t;

void threadFunc(threadParam_t* param) {
    int k = param->k;           // ��ȥ���ִ�
    int t_id = param->t_id;     // �̱߳��
    float** A = param->A;       // ����
    int n = param->n;           // �����С
    int i = k + t_id + 1;   // ��ȡ�Լ��ļ�������
    if (i < n) { // ����Ƿ�Խ��
        for (int j = k + 1; j < n; ++j) {
            A[i][j] -= A[i][k] * A[k][j];
        }
        A[i][k] = 0;
    }
}

void gaussEliminationMPI(float** A, int N, int rank, int size) {
    for (int k = 0; k < N; ++k) {
        // �ҵ���Ԫ�����㲥�����н���
        if (k % size == rank) {
            float pivot = A[k][k];
            for (int j = k + 1; j < N; ++j) {
                A[k][j] /= pivot;
            }
            A[k][k] = 1.0;
        }
        MPI_Bcast(&A[k][0], N, MPI_FLOAT, k % size, MPI_COMM_WORLD);

        // ÿ��������ȥ���������
        if (rank == k % size) {
            // ���߳̽��г�������
            int worker_count = N - 1 - k; // �����߳�����
            threadParam_t* param = new threadParam_t[worker_count];
#pragma omp parallel for
            for (int t_id = 0; t_id < worker_count; t_id++) {
                param[t_id].k = k;
                param[t_id].t_id = t_id;
                param[t_id].A = A;
                param[t_id].n = N;
            }

            // ������������
#pragma omp parallel for
            for (int t_id = 0; t_id < worker_count; t_id++) {
                threadFunc(&param[t_id]);
            }
        }
    }
}

int main(int argc, char* argv[]) {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("parallel_gauss_omp_mpi.csv");

    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    std::cout << "111" << std::endl;
    double start, end;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; i++) {
            A[i] = new float[N];
        }
        std::cout << "222" << std::endl;
        if (rank == 0) {
            std::stringstream ss;
            ss << sizeIndex + 1;
            std::ifstream infile("matrix" + ss.str() + ".txt");
            for (int i = 0; i < N; ++i) {
                for (int j = 0; j < N; ++j) {
                    infile >> A[i][j];
                }
            }
            infile.close();
        }
        std::cout << "333" << std::endl;
        start = MPI_Wtime();

        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        gaussEliminationMPI(A, N, rank, size);
        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        
        end = MPI_Wtime();
        std::cout << "444" << std::endl;
        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }
        std::cout << "555" << std::endl;
        for (int i = 0; i < N; i++) {
            delete[] A[i];
        }
        delete[] A;
    }

    MPI_Finalize();
    outfile.close();
    return 0;
}


/*
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <omp.h>
#include <mpi.h>

void gaussElimination(float** A, int N, int rank, int size) {
    for (int k = 0; k < N; ++k) {
        // �ҵ���Ԫ�����㲥�����н���
        if (k % size == rank) {
            float pivot = A[k][k];
            for (int j = k + 1; j < N; ++j) {
                A[k][j] /= pivot;
            }
            A[k][k] = 1.0;
        }
        MPI_Bcast(&A[k][0], N, MPI_FLOAT, k % size, MPI_COMM_WORLD);

        // ÿ��������ȥ���������
#pragma omp parallel for num_threads(16)
        for (int i = k + 1; i < N; ++i) {
            if (i % size == rank) {
                float factor = A[i][k];
                for (int j = k + 1; j < N; ++j) {
                    A[i][j] -= A[k][j] * factor;
                }
                A[i][k] = 0.0;
            }
        }
    }
}

int main(int argc, char* argv[]) {
    std::vector<int> sizes = { 100, 250, 500, 750, 1000, 2000, 3000, 4000 };
    std::ofstream outfile("parallel_gauss_omp.csv");

    MPI_Init(&argc, &argv);
    std::cout << "111" << std::endl;
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double start, end;
    std::cout << "222" << std::endl;
    for (int sizeIndex = 0; sizeIndex < sizes.size(); ++sizeIndex) {
        int N = sizes[sizeIndex];
        float** A = new float* [N];
        for (int i = 0; i < N; i++) {
            A[i] = new float[N];
        }
        std::cout << "333" << std::endl;
        std::stringstream ss;
        ss << sizeIndex + 1;
        std::ifstream infile("matrix" + ss.str() + ".txt");
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                infile >> A[i][j];
            }
        }
        infile.close();
        std::cout << "444" << std::endl;

        start = MPI_Wtime();
        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        gaussElimination(A, N, rank, size);
        MPI_Barrier(MPI_COMM_WORLD); // ͬ�����н���
        end = MPI_Wtime();
        std::cout << "555" << std::endl;

        if (rank == 0) {
            double elapsed = end - start;
            std::cout << "Matrix size: " << N << ", Time taken: " << elapsed << " seconds.\n";
            outfile << sizeIndex + 1 << ", " << N << ", " << elapsed << std::endl;
        }
        std::cout << "666" << std::endl;

        for (int i = 0; i < N; i++) {
            delete[] A[i];
        }
        delete[] A;
    }

    MPI_Finalize();
    outfile.close();
    return 0;
}
*/